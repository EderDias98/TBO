#ifndef DIJIKSTRA_H
#define DIJIKSTRA_H

#include "pilha.h"
void calcula(Pilha* pil1, Pilha* pil2, char*str);





#endif
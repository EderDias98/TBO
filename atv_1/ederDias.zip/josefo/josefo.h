#ifndef JOSEFO_H
#define JOSEFO_H
#include <stdio.h>
#include <stdlib.h>

int* criaLista(int N);
void descobreLider(int* lista,int N,int M);




#endif